import express from "express";
import { createServer } from "http";
import { Server } from "socket.io";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const httpServer = createServer(app);
  const io = new Server(httpServer, {
    cors: {
      origin: "*",
      methods: ["GET", "POST"],
    },
  });

  const PORT = 3000;

  // Store active users and their rooms
  const users = new Map();

  io.on("connection", (socket) => {
    console.log("A user connected:", socket.id);

    socket.on("join-room", ({ roomId, username }) => {
      socket.join(roomId);
      users.set(socket.id, { username, roomId });
      
      // Notify others in the room
      socket.to(roomId).emit("user-joined", { username });
      console.log(`${username} joined room: ${roomId}`);
    });

    socket.on("send-message", ({ roomId, message, username, timestamp }) => {
      io.to(roomId).emit("receive-message", {
        username,
        message,
        timestamp,
        id: Math.random().toString(36).substr(2, 9),
      });
    });

    socket.on("disconnect", () => {
      const user = users.get(socket.id);
      if (user) {
        socket.to(user.roomId).emit("user-left", { username: user.username });
        users.delete(socket.id);
      }
      console.log("User disconnected:", socket.id);
    });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  httpServer.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
