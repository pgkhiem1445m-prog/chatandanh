import React, { useState, useEffect, useRef } from "react";
import { io, Socket } from "socket.io-client";
import { 
  MessageSquare, 
  Send, 
  User, 
  Users, 
  Hash, 
  LogOut, 
  Shield, 
  GraduationCap,
  ChevronRight,
  Sparkles
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { cn } from "./lib/utils";

// --- Types ---
interface Message {
  id: string;
  username: string;
  message: string;
  timestamp: string;
  isMe?: boolean;
}

interface UserIdentity {
  username: string;
  color: string;
  avatar: string;
}

// --- Constants ---
const ADJECTIVES = ["Happy", "Smart", "Cool", "Fast", "Brave", "Kind", "Wise", "Witty", "Calm", "Bold"];
const NOUNS = ["Owl", "Fox", "Panda", "Koala", "Tiger", "Eagle", "Dolphin", "Lion", "Wolf", "Bear"];
const COLORS = [
  "bg-blue-500", "bg-purple-500", "bg-pink-500", "bg-emerald-500", 
  "bg-orange-500", "bg-indigo-500", "bg-rose-500", "bg-cyan-500"
];
const ROOMS = [
  { id: "general", name: "General Chat", desc: "Open discussion for everyone" },
  { id: "study", name: "Study Group", desc: "Help each other with homework" },
  { id: "campus", name: "Campus Life", desc: "Events, food, and student life" },
  { id: "confessions", name: "Confessions", desc: "Share your secrets anonymously" },
];

// --- Helpers ---
const generateIdentity = (): UserIdentity => {
  const adj = ADJECTIVES[Math.floor(Math.random() * ADJECTIVES.length)];
  const noun = NOUNS[Math.floor(Math.random() * NOUNS.length)];
  const color = COLORS[Math.floor(Math.random() * COLORS.length)];
  return {
    username: `${adj} ${noun}`,
    color,
    avatar: noun[0],
  };
};

export default function App() {
  const [socket, setSocket] = useState<Socket | null>(null);
  const [identity, setIdentity] = useState<UserIdentity | null>(null);
  const [currentRoom, setCurrentRoom] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState("");
  const [isJoined, setIsJoined] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Initialize Socket
  useEffect(() => {
    const newSocket = io();
    setSocket(newSocket);

    newSocket.on("receive-message", (msg: Message) => {
      setMessages((prev) => [...prev, msg]);
    });

    newSocket.on("user-joined", ({ username }) => {
      setMessages((prev) => [
        ...prev,
        { 
          id: `system-${Date.now()}`, 
          username: "System", 
          message: `${username} has joined the chat.`, 
          timestamp: new Date().toLocaleTimeString() 
        }
      ]);
    });

    newSocket.on("user-left", ({ username }) => {
      setMessages((prev) => [
        ...prev,
        { 
          id: `system-${Date.now()}`, 
          username: "System", 
          message: `${username} has left the chat.`, 
          timestamp: new Date().toLocaleTimeString() 
        }
      ]);
    });

    return () => {
      newSocket.close();
    };
  }, []);

  // Scroll to bottom
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleJoin = (roomId: string) => {
    if (!socket) return;
    
    const newIdentity = generateIdentity();
    setIdentity(newIdentity);
    setCurrentRoom(roomId);
    setMessages([]);
    
    socket.emit("join-room", { roomId, username: newIdentity.username });
    setIsJoined(true);
  };

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!socket || !inputValue.trim() || !identity || !currentRoom) return;

    const messageData = {
      roomId: currentRoom,
      message: inputValue,
      username: identity.username,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    socket.emit("send-message", messageData);
    setInputValue("");
  };

  const handleLeave = () => {
    setIsJoined(false);
    setCurrentRoom(null);
    setIdentity(null);
    setMessages([]);
  };

  if (!isJoined) {
    return (
      <div className="min-h-screen bg-[#F5F5F0] flex flex-col items-center justify-center p-6 font-sans">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="max-w-4xl w-full grid grid-cols-1 md:grid-cols-2 gap-12 items-center"
        >
          {/* Hero Section */}
          <div className="space-y-8">
            <div className="flex items-center gap-3 text-emerald-700">
              <GraduationCap size={32} />
              <span className="text-xl font-bold tracking-tight">UniChat</span>
            </div>
            
            <h1 className="text-6xl font-serif font-light leading-tight text-zinc-900">
              Speak your <span className="italic">mind</span>, stay <span className="italic">anonymous</span>.
            </h1>
            
            <p className="text-lg text-zinc-600 leading-relaxed max-w-md">
              A dedicated space for students to connect, share confessions, and help each other without the pressure of identity.
            </p>

            <div className="flex items-center gap-4 text-sm font-medium text-zinc-500">
              <div className="flex items-center gap-1.5">
                <Shield size={16} className="text-emerald-600" />
                <span>Encrypted</span>
              </div>
              <div className="w-1 h-1 rounded-full bg-zinc-300" />
              <div className="flex items-center gap-1.5">
                <Sparkles size={16} className="text-emerald-600" />
                <span>Real-time</span>
              </div>
            </div>
          </div>

          {/* Room Selection */}
          <div className="bg-white rounded-[32px] p-8 shadow-xl shadow-zinc-200/50 border border-zinc-100">
            <h2 className="text-2xl font-serif mb-6 text-zinc-900">Choose a Room</h2>
            <div className="space-y-3">
              {ROOMS.map((room) => (
                <button
                  key={room.id}
                  onClick={() => handleJoin(room.id)}
                  className="w-full group flex items-center justify-between p-4 rounded-2xl border border-zinc-100 hover:border-emerald-200 hover:bg-emerald-50/30 transition-all duration-300 text-left"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-xl bg-zinc-50 flex items-center justify-center text-zinc-400 group-hover:bg-emerald-100 group-hover:text-emerald-600 transition-colors">
                      <Hash size={20} />
                    </div>
                    <div>
                      <div className="font-medium text-zinc-900">{room.name}</div>
                      <div className="text-xs text-zinc-500">{room.desc}</div>
                    </div>
                  </div>
                  <ChevronRight size={18} className="text-zinc-300 group-hover:text-emerald-400 group-hover:translate-x-1 transition-all" />
                </button>
              ))}
            </div>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="h-screen bg-[#F5F5F0] flex flex-col font-sans">
      {/* Header */}
      <header className="bg-white border-b border-zinc-200 px-6 py-4 flex items-center justify-between shrink-0">
        <div className="flex items-center gap-4">
          <button 
            onClick={handleLeave}
            className="p-2 hover:bg-zinc-50 rounded-full transition-colors text-zinc-400 hover:text-zinc-600"
          >
            <LogOut size={20} />
          </button>
          <div className="h-6 w-px bg-zinc-200" />
          <div>
            <h3 className="font-serif text-lg text-zinc-900 flex items-center gap-2">
              <Hash size={18} className="text-emerald-600" />
              {ROOMS.find(r => r.id === currentRoom)?.name}
            </h3>
            <div className="flex items-center gap-1.5 text-[10px] uppercase tracking-wider font-bold text-zinc-400">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
              Live Session
            </div>
          </div>
        </div>

        <div className="flex items-center gap-3 bg-zinc-50 px-4 py-2 rounded-full border border-zinc-100">
          <div className={cn("w-8 h-8 rounded-full flex items-center justify-center text-white font-bold text-sm", identity?.color)}>
            {identity?.avatar}
          </div>
          <div className="text-sm font-medium text-zinc-700">{identity?.username}</div>
        </div>
      </header>

      {/* Messages Area */}
      <main className="flex-1 overflow-y-auto p-6 space-y-6">
        <div className="max-w-3xl mx-auto space-y-6">
          <AnimatePresence initial={false}>
            {messages.map((msg) => {
              const isSystem = msg.username === "System";
              const isMe = msg.username === identity?.username;

              if (isSystem) {
                return (
                  <motion.div 
                    key={msg.id}
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    className="flex justify-center"
                  >
                    <span className="bg-zinc-200/50 text-zinc-500 text-[11px] px-3 py-1 rounded-full font-medium uppercase tracking-tight">
                      {msg.message}
                    </span>
                  </motion.div>
                );
              }

              return (
                <motion.div
                  key={msg.id}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={cn(
                    "flex flex-col max-w-[80%]",
                    isMe ? "ml-auto items-end" : "items-start"
                  )}
                >
                  <div className="flex items-center gap-2 mb-1 px-1">
                    <span className="text-[11px] font-bold text-zinc-400 uppercase tracking-wider">
                      {msg.username}
                    </span>
                    <span className="text-[10px] text-zinc-300">{msg.timestamp}</span>
                  </div>
                  <div className={cn(
                    "px-5 py-3 rounded-2xl text-sm leading-relaxed shadow-sm",
                    isMe 
                      ? "bg-emerald-600 text-white rounded-tr-none" 
                      : "bg-white text-zinc-800 border border-zinc-100 rounded-tl-none"
                  )}>
                    {msg.message}
                  </div>
                </motion.div>
              );
            })}
          </AnimatePresence>
          <div ref={messagesEndRef} />
        </div>
      </main>

      {/* Input Area */}
      <footer className="bg-white border-t border-zinc-200 p-6 shrink-0">
        <form 
          onSubmit={handleSendMessage}
          className="max-w-3xl mx-auto relative"
        >
          <input
            type="text"
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            placeholder="Type your message..."
            className="w-full bg-zinc-50 border border-zinc-200 rounded-2xl px-6 py-4 pr-16 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all text-zinc-800 placeholder:text-zinc-400"
          />
          <button
            type="submit"
            disabled={!inputValue.trim()}
            className="absolute right-2 top-2 bottom-2 px-4 bg-emerald-600 text-white rounded-xl hover:bg-emerald-700 disabled:opacity-50 disabled:hover:bg-emerald-600 transition-all flex items-center justify-center"
          >
            <Send size={18} />
          </button>
        </form>
        <p className="text-center text-[10px] text-zinc-400 mt-4 uppercase tracking-widest font-medium">
          Your identity is protected. Be kind and respectful.
        </p>
      </footer>
    </div>
  );
}
